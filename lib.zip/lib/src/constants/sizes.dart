const tDefaultSize = 30.0;
const tButtonHeight = 15.0;
const tFormHeight = 30.0;
const tHomePadding = 20.0;
const tHomeCardPadding = 10.0;
